package com.demo.rewards;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RewardsAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
