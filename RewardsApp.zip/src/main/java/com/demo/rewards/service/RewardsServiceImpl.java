package com.demo.rewards.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.rewards.model.Customer;
import com.demo.rewards.model.Transactions;
import com.demo.rewards.repository.CustomerRewardRepository;

@Service
public class RewardsServiceImpl implements RewardsService {
	
	@Autowired
	CustomerRewardRepository customerRewardRepository;
	
	@Override
	public List<Customer> calculateRewardsForAll() {		
		List<Customer> customerList = customerRewardRepository.findAll();
		if (customerList != null && !customerList.isEmpty()) {
			for (Customer customer : customerList) {
				Set<Transactions> setOfTransaction = customer.getTransactions();
				setRewardsPerMonth(setOfTransaction, customer);
			}
		}
		return customerList;
	}

	@Override
	public Customer calculateRewardsbyId(Integer customerId) {
		Customer customerReward = customerRewardRepository.findById(customerId).orElse(null);
		if(customerReward != null) {
			Set<Transactions> setOfTransaction = customerReward.getTransactions();
			setRewardsPerMonth(setOfTransaction, customerReward);
		}
		return customerReward;
	}
	
	private void setRewardsPerMonth(Set<Transactions> setOfTransaction, Customer customer) {
		LocalDate todayDate = LocalDate.now();
		for (Transactions transaction : setOfTransaction) {
			int transactionMon = transaction.getCreation_date().getMonth() + 1;
			int transactionYear = transaction.getCreation_date().getYear() + 1900;
			if ((todayDate.getYear() == transactionYear) && (todayDate.getMonth().getValue() == transactionMon))
				customer.setThirdMonthRewards(customer.getThirdMonthRewards()
						+ calculateRewardAmountPerTrans(transaction.getTransaction_amount()));
			else if ((todayDate.minusMonths(1).getYear() == transactionYear)
					&& (todayDate.minusMonths(1).getMonth().getValue() == transactionMon))
				customer.setSecondMonthRewards(customer.getSecondMonthRewards()
						+ calculateRewardAmountPerTrans(transaction.getTransaction_amount()));
			else if ((todayDate.minusMonths(2).getYear() == transactionYear)
					&& (todayDate.minusMonths(2).getMonth().getValue() == transactionMon))
				customer.setFirstMonthRewards(customer.getFirstMonthRewards()
						+ calculateRewardAmountPerTrans(transaction.getTransaction_amount()));
		}
	}
	
	private int calculateRewardAmountPerTrans(int transactionAmount) {
		int rewardAmount = 0;
		if (transactionAmount > 50 && transactionAmount <= 100) {
			rewardAmount = transactionAmount - 50;
		} else if (transactionAmount > 100) {
			rewardAmount = (2 * (transactionAmount - 100) + 50);
		}
		return rewardAmount;
	}
}
