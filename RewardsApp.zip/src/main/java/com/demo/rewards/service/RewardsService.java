package com.demo.rewards.service;

import java.util.List;

import com.demo.rewards.model.Customer;

public interface RewardsService {
	
	List<Customer> calculateRewardsForAll();

	Customer calculateRewardsbyId(Integer id);
	
	
}
