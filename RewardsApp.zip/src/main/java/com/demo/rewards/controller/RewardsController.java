package com.demo.rewards.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.rewards.model.Customer;
import com.demo.rewards.service.RewardsService;

@RestController
@RequestMapping("/")
public class RewardsController {

	@Autowired
	public RewardsService rewardsService;
	
	@GetMapping(value="/customer/rewards", produces = "application/json")
    public ResponseEntity<Object> getAllCustomerRewards() throws Exception {
		List<Customer> customerList = rewardsService.calculateRewardsForAll();
		if (customerList.isEmpty() || customerList.size() == 0) {
			throw new Exception("No Customers");
		}
		
		return new ResponseEntity<>(customerList, HttpStatus.OK);
	}
	
	@GetMapping(value="/customer/rewards/{id}", produces = "application/json")
    public ResponseEntity<Customer> getCustomerRewardsById(@PathVariable Integer id) throws Exception {
		Customer customerRewardsSummary = rewardsService.calculateRewardsbyId(id);
		if (customerRewardsSummary == null) {
			throw new Exception("No Customer/Rewards");
		}
		return new ResponseEntity<Customer>(customerRewardsSummary, HttpStatus.OK);
	}
	
}
