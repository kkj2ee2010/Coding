DROP TABLE IF EXISTS customer;
  
CREATE TABLE customer (
  id INT PRIMARY KEY,
  name VARCHAR(150) NOT NULL);


DROP TABLE IF EXISTS transaction;
  
CREATE TABLE transaction (
  id INT PRIMARY KEY,
  customer_id INT,
  transaction_amount INT,
  creation_date DATE  
);

ALTER TABLE TRANSACTION ADD FOREIGN KEY (CUSTOMER_ID) REFERENCES CUSTOMER (ID);

Insert into CUSTOMER values(1,'Hello');
Insert into CUSTOMER values(2,'Welcome');

Insert into Transaction values(1001,1,50,'2022-11-03');
Insert into Transaction values(1002,1,10,'2022-11-04');
Insert into Transaction values(1003,1,120,'2022-10-04');
Insert into Transaction values(1004,1,110,'2022-11-04');
Insert into Transaction values(1005,2,120,'2022-10-04');
Insert into Transaction values(1006,2,110,'2022-11-04');
Insert into Transaction values(1007,1,130,'2022-09-04');
Insert into Transaction values(1008,1,140,'2022-08-04');
Insert into Transaction values(1009,1,150,'2022-10-04');
Insert into Transaction values(1010,1,160,'2022-08-03');

COMMIT;